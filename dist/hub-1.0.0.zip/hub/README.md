# Hub for Geeklog

Hub is an interoperability and content-relationship plugin for Geeklog.

Version **1.0.0 (development)** is the stabilization milestone for the completed relationship, lifecycle, editorial, integrity, multisite and multilingual-context layers. No release is implied until the 1.0 compatibility, upgrade and documentation checks are complete.

## Requirements

- Geeklog 2.1.1 or newer
- PHP 5.6 or newer

## Pillars and manual relations (finalized in 0.3.0)

From **Hub administration → Pillars & manual relations**, an administrator can create a Hub pillar from a Geeklog Static Page and attach complementary content by stable `type + id` identity.

Hub stores:

- the pillar source as `source_type + source_id`;
- related items as `item_type + item_id`;
- a Hub-owned structural `relation_role` (`related`, `sub-pillar`, `satellite`, `support`, `equivalent`);
- manual order;
- enabled/disabled state;
- source titles resolved dynamically from the owning content provider.

Hub does **not** store another plugin's canonical URL or a separate public title as source of truth. Titles and URLs are resolved dynamically through `PLG_getItemInfo()` when available, so ownership remains with the source plugin.

The initial 0.3.0 target is deliberately limited to Static Pages as pillars. Relations may point to any provider/object identity that Geeklog can resolve. Static Page topic assignments remain a discovery signal only and are independent from explicit Hub relationships.

The relation editor now lists only active, resolvable Geeklog Item Info provider types. When the selected provider exposes the shared `content.collection` / `plugin_getiteminfo_*('*', ...)` contract, Hub loads up to 100 selectable objects dynamically and stores only the selected stable ID. Providers without a generic collection remain usable through an explicit manual-ID fallback. Hub does not query plugin-private tables.

Saved relations display integrity diagnostics when an identity can no longer be resolved; Hub keeps the stable identity instead of deleting it automatically because a provider may simply be disabled or temporarily unavailable.

### Bidirectional public navigation

Hub renders enabled pillar relations as normal server-side HTML links and resolves current titles and URLs from the owning provider at render time.

For Core articles, Hub also renders one reciprocal backlink to each enabled pillar in the full article body. This has been smoke-tested on Geeklog 2.1.1 and 2.2.2.

Hub's generic `plugin_itemdisplay_hub()` backlink path is prepared for Forum, Documents, Videos, Maps, MediaGallery and Polls. When one of those providers calls `PLG_itemDisplay($id, $type)` on its full public item view, Hub can render the reciprocal pillar backlink without any provider-specific dependency. Articles and Static Pages keep their dedicated Hub integration paths to avoid duplicate output.

The original **Find suggestions** mode introduced the first topic-based editorial aid. Hub 0.8.0 has since generalized this into deterministic editorial inventory, explainable relation/pillar suggestions, close-content review, content-gap opportunities, persisted editorial decisions and roadmap exports.

All Hub administration pages share the same navigation between the Hub home, pillars/relations, interoperability audit and article link audit.

## Public relationship navigation (0.4.0)

On an enabled Static Page pillar, Hub now resolves enabled relations at render time and appends a crawlable **Related content / Contenus liés** section. The stored Static Page body is never rewritten. Relationship order follows the administrator-defined `position`, while missing, disabled or unresolved targets are omitted from public output.

Hub also exposes `plugin_itemdisplay_hub()`. When a core or plugin content renderer calls Geeklog's `PLG_itemDisplay($id, $type)`, Hub can return a **Part of / Dans ce dossier** backlink to the enabled pillar. This keeps backlinks generic and avoids provider-specific database access. Providers that do not render `PLG_itemDisplay()` fragments may require a later fallback adapter.

Core articles are handled without a Core patch: Geeklog already calls `PLG_templateSetVars()` for full story templates and exposes `story_id` / `story_display_type`. Hub uses that generic hook only on full article pages and appends the **Part of / Dans ce dossier** backlink to the prepared story body variables used by Geeklog themes. This avoids relying on late footer variables whose rendering differs across Geeklog 2.1.1 themes, while keeping the backlink server-rendered and crawlable. Forum, Documents, Videos and Maps currently do not expose an equivalent generic public placement hook in the reviewed source, so Hub does not inject backlinks into them through JavaScript or private-table logic.

The SEO value comes from the resulting HTML links, not from the database relationship alone: approved relationships become an explicit internal-link graph between a central pillar and complementary content. Hub now keeps graph structure and editorial function separate: `relation_role` describes structural position (`related`, `sub-pillar`, `satellite`, `support`), while optional `editorial_role` describes functions such as guide, tutorial, video, download, discussion, case study or reference without changing the stable `type + id` identity.

## Article link audit (introduced in 0.1.1)

From **Hub administration → Article link audit**, select a destination Static Page and click **Run audit**.

Hub discovers the topics assigned to that Static Page automatically, gathers the published non-draft articles from those topics, deduplicates articles assigned to more than one matching topic, and lists only the articles whose introduction and body do not contain a hyperlink to the selected page. Each suggestion also shows the matching assigned topic(s), making the editorial reason for the suggestion explicit. Relative and absolute links, HTTP/HTTPS, www/non-www and equivalent query-string order are recognized. Each result provides **View** and **Edit** links.

When Hub is enabled, normal Static Page rendering also appends the visible topics assigned to that page using Geeklog's native `TOPIC_relatedTopics()` renderer. Static Pages therefore use the same localized `related-topics` markup as articles (for example `Classé dans :` in French). The stored `sp_content` is not modified. The audit also exposes the topics assigned to the selected Static Page. An administrator can optionally edit the page and place any of those topic links manually at a preferred position in the page content.

The audit does not modify article content. This first implementation targets Geeklog core articles and Static Pages only.

The audit also exposes **Views, comments, matched-topic count, article age and publication date** as transparent prioritization signals. Results can be sorted by views, comments, matched topics, publication date or title. When the selected Static Page is already a Hub pillar, an administrator can create the corresponding article relation directly from the audit; existing Hub relations are marked **Already related** instead of offering a duplicate action.

## Static Page topic semantics

Geeklog Static Pages historically use topic assignments partly as placement rules, especially for center-block display. Hub therefore distinguishes **specific Geeklog topics** from the native **All** and **Home page only** placement options.

- `All` and `Home page only` are never treated as editorial topic relationships.
- Specific topic assignments may be used by Hub as a discovery/suggestion signal.
- A shared Geeklog topic is not an approved editorial relationship.
- Future Hub pillar/relationship records remain explicit and independent from Static Page placement settings.

Hub does not require existing Static Pages to be reconfigured merely to satisfy Hub.

## Generic capability declarations

Hub now detects optional generic `plugin_getcapabilities_*()` declarations when a plugin exposes them. The expected declaration is versioned with a `schema` value and may advertise generic `roles`, `capabilities`, and an optional `lifecycle` block describing emitted/listened events and `sub_type` support.

These declarations are treated as plugin-supplied metadata only. Hub keeps them separate from runtime callback detection, source evidence, permissions and inferred role/readiness. The optional `lifecycle` block remains declarative metadata and never replaces runtime/source proof. This avoids inventing a Hub-specific capability API while allowing plugins such as Videos or Monitor to describe capabilities that cannot be inferred safely.

## Shared Memorandum alignment

Hub consumes the shared interoperability conventions maintained in `hostellerie/memorandum`; it does not define a parallel Hub-only plugin contract. In particular:

- normalized content remains owned by `plugin_getiteminfo_*()` and related Geeklog APIs;
- lifecycle remains owned by `PLG_itemSaved()` / `PLG_itemDeleted()`;
- specialized provider operations remain owned by bounded services;
- capability declarations describe existing provider surfaces and do not grant authorization;
- Hub owns relationships/context, Agent owns provider-neutral machine access, and external Connectors adapt Agent to a client/protocol.

Hub's own `plugin.json` follows the same recommended static metadata convention.

## Reusable service catalogue

Hub 0.2.0 exposes a reusable runtime catalogue through `HUB_serviceCatalogue()`. It reports whether the plugin service dispatcher is present and lists loaded `service_*_<plugin>()` actions with reflected signatures. The catalogue is descriptive only: Hub does not invoke the service, bypass ACL checks, or take ownership of the service implementation.

Hub itself uses the same shared declaration contract through `plugin_getcapabilities_hub()`. Its declared roles are `relationship`, `orchestrator` and `service`. Hub does not advertise future `hub.*` capabilities until the corresponding provider-owned service/read surface actually exists.

## Current interoperability audit

The permanent Plugin Interoperability Audit follows the shared Memorandum model and separates three layers instead of treating every callback as one Hub-specific checklist.

### Content interoperability baseline

For content-owning providers Hub reports Item Info, stable object types, lifecycle save/delete evidence, URL resolution and services. It also reports **shared content contract evidence** for the recommended Item Info collection conventions:

- `content.collection` declarations;
- source evidence for `$id = '*'`;
- source evidence for collection options `since`, `limit` and `order`;
- source evidence for optional `hits` / `hits-desc` popularity support.

Hub deliberately does **not** execute arbitrary `plugin_getiteminfo_*('*', ...)` provider queries merely to prove these conventions. Declaration/source evidence remains distinct from runtime proof and does not currently change readiness scoring.

### Extended Geeklog integration

Hub reports native optional/distribution surfaces separately, including Related Items, Blocks, Autotags, Search, services, Content Syndication, XML Sitemap, statistics, language overrides and other detectable Geeklog APIs. Optional integration does not reduce a provider's core content-readiness score merely because a feature is irrelevant to that provider.

### Shared capabilities and modernization metadata

Hub detects the provider-neutral `plugin_getcapabilities_*()` convention, reusable service actions, plugin-owned render entry points and the optional static `plugin.json` manifest. The manifest is validated as modernization metadata but is not a Geeklog Core requirement and does not affect readiness scoring.

### Capability implementation evidence

When a provider declares a shared capability, Hub cross-checks the normal Memorandum implementation surface when it can do so safely. Examples include `content.read` → Item Info, `content.lifecycle` → save/delete lifecycle evidence, `content.url.resolve` → ID-to-URL or Item Info, and `dashboard.summary` → the bounded `dashboard_summary` service.

This reconciliation is diagnostic only. A missing or ambiguous implementation surface produces a review recommendation but does not make the declaration invalid, grant authorization, or change the role/readiness score automatically. Specialized provider capabilities remain accepted when Hub cannot infer their implementation surface.

Runtime-detected callbacks are kept distinct from source evidence, provider declarations and inference. Hub never presents source scanning as proof that every mutation path emits a lifecycle notification. The full runtime `plugin_*_<plugin>()` surface remains available under the collapsed **Advanced API surface** section.

See `ROADMAP.md` for the current development milestone and the completed lifecycle, editorial, integrity and multisite-context layers.

## 0.1.0 audit details

The audit includes Hub itself, exposes detected callback/function names and autotag names, and provides per-plugin recommendations in collapsed **Details / Recommendations** sections. The most Hub-relevant information is shown first; embedding/discovery helpers are separated and the full Plugin API surface is hidden under **Advanced API surface** by default.

## Role-aware readiness

Hub combines provider-declared roles from the shared capability contract with technical evidence from existing Geeklog APIs. Addressable-content evidence remains authoritative for identifying a content owner; otherwise an explicit provider role can identify **Orchestrator**, **Relationship**, **Diagnostic**, **Navigation**, **Communication**, **Presentation**, **Service** or **Infrastructure** providers.

The audit records whether the primary role is `declared`, `inferred` or `declared+inferred`, and preserves all declared secondary roles. Content providers are evaluated on Item Info, stable object types and save/delete lifecycle emission. Service and presentation providers retain role-specific checks. Diagnostic, relationship, navigation, communication and infrastructure roles are not penalized for missing content-owner APIs.

## Audit cache

The Plugin Interoperability Audit caches its normalized audit data for 10 minutes through Geeklog's native cache API. The cache is keyed by a fingerprint containing the active plugin list and versions plus the Hub, Geeklog and PHP versions. The administration page provides **Refresh audit** to bypass the cache explicitly, which is especially useful during plugin development when source code changes without a version bump.

The HTML audit and Markdown export consume the same cached dataset.

## Markdown export

The administration audit includes **Export audit as Markdown (.md)**. The export filename and report title identify the audited site using Geeklog's configured site name. The report contains environment information, the summary matrix, inferred roles, role-aware readiness, callbacks, lifecycle evidence, object types, service signatures, advanced API surface and developer recommendations. It can be attached directly to an issue or sent to a plugin maintainer.

### Final 0.1.0 audit additions

- detects `plugin_idtourl_*()` as an optional content interoperability capability
- reports whether lifecycle listener callbacks are `sub_type`-aware (Geeklog 2.2.x) or legacy/no-`sub_type` (Geeklog 2.1.x)
- lists additional Geeklog capabilities such as `plugin_getlanguageoverrides_*()`, `plugin_usercontributed_*()` and `plugin_supportsrecaptcha_*()`
- exports all of the above in the Markdown developer report
- lifecycle source detection is token-based (`token_get_all()`), avoiding strings/comments/regex false positives

## Statistics capability

The audit reports native Geeklog statistics contribution through `plugin_showstats_*()` and `plugin_statssummary_*()` as **Full**, **Partial** or **None**. Statistics are informational and do not affect Hub readiness scores. This keeps open a future path for Hub to aggregate or present plugin-provided statistics without reading plugin tables directly.

## Distribution capabilities

The audit also reports native Geeklog distribution contracts without changing Hub readiness scores:

- **Content Syndication**: `plugin_getfeednames_*()`, `plugin_getfeedcontent_*()` and optional `plugin_feedupdatecheck_*()`
- **XML Sitemap contribution**: native `plugin_collectSitemapItems_*()` when available, with the XMLSitemap plugin's `PLG_getItemInfo(type, '*', ...)` fallback reported separately

These capabilities are informational interoperability signals. Hub does not read another plugin's tables to infer them.

## Hub read services

Hub currently exposes these read-only administrator services through Geeklog's native service dispatcher:

- `hub.affected.read` — resolve Hub contexts affected by one stable content identity;
- `hub.context.read` — traverse the approved Hub graph around one identity with bounded, cycle-safe traversal;
- `hub.related.read` — return immediate parent/child graph neighbors;
- `hub.pillar.read` — return one Hub pillar and its approved relation identities;
- `hub.suggestions.read` — return explainable read-only editorial candidates, currently including both new article relations for existing Static Page pillars and new Static Page pillar opportunities based on shared specific Geeklog topics and published articles.

These surfaces are protected by `hub.admin`. Hub advertises only capabilities whose service surface is implemented.

Structural `relation_role` is intentionally separate from optional `editorial_role`. Graph position remains `related`, `sub-pillar`, `satellite` or `support`, while editorial function can independently be `guide`, `tutorial`, `reference`, `case-study`, `download`, `video`, `discussion`, `resource`, `news` or `archive`. Editorial roles default to empty, are administrator-approved, and are never inferred automatically.

The suggestion service never creates or changes a relationship. Each current candidate keeps stable `type + id`, a suggested structural role and explicit `shared-topic` evidence so the administrator can decide whether to approve it.

Engagement and publication date are transparent ranking evidence only: shared topics determine candidate eligibility first, then views/comments may prioritize candidates with equivalent thematic evidence. Hub does not treat popularity as editorial approval. Keyword-based matching is intentionally deferred until Geeklog/providers expose a stable shared metadata contract; Hub does not parse HTML returned by `PLG_getRelatedItems()` to infer identities.

Temporal review signals are also advisory only. Hub can expose publication age plus explicit year/version markers found in article title/content (for example `2024`, `26.8`, `v1.5.0`) and recommend human review, but it never labels the content stale or obsolete automatically.

### Editorial / marketing mapping

Hub 0.8.0 exposes `hub.editorial.summary` as a read-only structural view of the approved relationship graph. It reports pillar/relation counts, structural roles, provider participation, nested pillars and multi-parent items without creating a second graph or duplicating provider content. Monitor and other consumers should use this service rather than query Hub persistence directly.

This first summary intentionally excludes broken-link/cluster-health diagnostics and inferred suggestions. Discovery/opportunity work belongs to 0.8.0; integrity/SEO health remains a separate 0.9.0 concern.

### Provider-owned specialized rendering

Hub can discover provider-declared `*.render` capabilities backed by native Geeklog `*_render` services. For one unambiguous renderer, Hub passes only the approved relation identities for that provider and lets the provider own filtering, presentation and CSS dependencies. If specialized rendering is unavailable, ambiguous, empty or fails, Hub automatically keeps its generic relationship links.

Videos 0.21.0 is the reference implementation through `videos.recommendations.render`. Hub does not call Videos private rendering functions and does not allow the renderer to expand a pillar beyond its approved Videos relations.

### IndexNow integration (0.6.0)

When IndexNow exposes the `indexnow.urls.submit` capability, Hub submits only additional public context pages affected by a Hub relationship, lifecycle or topic change. The directly changed object remains IndexNow's own lifecycle responsibility. Hub calls the native Geeklog `PLG_invokeService()` dispatcher and never reads the IndexNow key, calls its transport helpers, deduplicates URL batches or stores submission history. Older or absent IndexNow versions are a graceful no-op. When IndexNow also exposes `indexnow.status.read`, Hub administration shows only normalized readiness information (transport mode, key readiness, history availability and latest submission status); Hub never receives the key value or local key-file path.

## Development archive

The `Build installable archive` GitHub Actions workflow creates the archive matching the current plugin version (for example `dist/hub-1.0.0.zip`) and preserves previously generated version archives. The ZIP contains one top-level `hub/` directory and can be uploaded through Geeklog's plugin installer.


## Editorial roadmap exports

The read-only Editorial mapping administration page can build a deterministic 0.8 editorial roadmap from the approved Hub graph and explainable suggestion signals. It includes existing pillars, strongest relation candidates, new Static Page pillar opportunities, temporal review candidates and prioritized next actions.

The roadmap can be downloaded as Markdown or JSON. Diagnostics that belong to 0.9.0, including reciprocal-link health, orphan detection, broken/unresolved relations, canonical consistency and cluster health, are listed as deferred instead of being inferred prematurely.


## Suggestion decisions

Editorial suggestions remain human-controlled. In Relations administration, a candidate can be approved, dismissed, or deferred for 30 days.

- **Dismiss** hides that exact stable suggestion identity until an administrator restores it.
- **Defer 30 days** hides it temporarily and automatically lets it return after the stored expiry.
- **Restore** removes the persisted decision immediately.

Hub stores these decisions separately from approved relationships in `hub_suggestion_decisions`; dismissed or deferred candidates never become graph edges unless an administrator explicitly approves them.


## Close-content review

Hub 0.8.0 can flag article pairs for human review when they belong to the same Static Page pillar topic context and their titles are lexically close. The first deterministic rule requires at least one shared specific topic, at least two common significant title tokens, and Jaccard title-token similarity of 50% or more.

This is not an automatic SEO cannibalization diagnosis. Hub exposes the exact shared topics, common title tokens and similarity score, and never merges, redirects or rewrites content. Review pairs can be deferred for 30 days, dismissed, or restored through Relations administration.


## Content-gap opportunities

Hub 0.8.0 can identify simple deterministic topic-coverage gaps for Static Page pillars. For each specific Geeklog topic assigned to a pillar:

- **0 published articles** → create-content opportunity;
- **1 published article** → thin-coverage review;
- **2 or more published articles** → no content-gap signal from this rule.

These are editorial planning signals, not SEO verdicts. Each gap keeps its topic identity and exact published-article count as evidence. Content-gap suggestions can be deferred for 30 days, dismissed, or restored from Editorial mapping.


## Integrity summary (0.9.0)

Hub 0.9.0 introduces `hub.integrity.summary`, a normalized read-only diagnostic surface over the approved relationship graph. The first slice reports pillar-source resolution, approved relation resolution/renderability, provider participation and backlink-integration evidence.

Backlink diagnostics deliberately distinguish three evidence levels:

- **hub-managed** — Hub owns the known rendering path;
- **integration-available** — a generic provider integration hook is available, but runtime output is not asserted;
- **unconfirmed** — Hub has no confirmed generic backlink placement contract.

This prevents Monitor, Agent or other consumers from treating integration capability as proof that a backlink is present on a rendered provider page.

Reciprocal-link verification is stricter still: for Core articles, Hub can verify that the expected pillar backlink fragment is generated and owns the placement path, so the relation is reported as `hub-rendered`. For generic providers, Hub may report `fragment-available-runtime-unverified` or `integration-available-unverified`; neither status is treated as proof of a backlink on the rendered provider page.


### Hub-unconnected content

Hub 0.9.0 can review provider-owned content exposed through the shared `content.collection` contract and identify items that are absent from the enabled Hub relationship graph.

These items are reported as:

`hub-unconnected`

This is intentionally **not** an SEO-orphan verdict. Hub does not know every hyperlink, menu, sitemap, feed or provider-owned navigation path on the site, so absence from the Hub graph alone cannot prove that a page is globally orphaned.

The diagnostic:

- uses only providers exposing the shared collection contract;
- does not scan plugin-private tables;
- does not use the Core article SQL selector for this cross-provider check;
- excludes collection items already present as a Hub pillar or approved relation;
- reports the collection limit and whether the returned result may be truncated.


### Affected-page diagnostics

The existing `hub.affected.read` service now keeps its dependency-context output and adds public-page diagnostics. For each affected Hub pillar it reports the current source identity, dependency reason, whether the public page resolves, its current title/URL, and any resolution diagnostic.

The dependency calculation is not duplicated: `HUB_getAffectedContexts()` remains the authoritative source for which Hub contexts are affected. The 0.9 integrity layer only enriches those contexts for reporting.


### Sitemap and feed interoperability

Hub 0.9.0 reports provider-owned distribution capabilities for content types participating in the enabled Hub graph.

For XML Sitemap, Hub recognizes the shared Geeklog paths documented by the Memorandum:

- native `plugin_collectSitemapItems_PLUGIN()` when present;
- otherwise the shared `content.collection` / Item Info collection fallback when available.

For feeds/syndication, Hub recognizes:

- native `plugin_getfeednames_PLUGIN()` + `plugin_getfeedcontent_PLUGIN()`;
- the shared `content.syndication` capability declaration.

These diagnostics are opportunities, not failures. A provider may legitimately be unsuitable for feeds. Hub never becomes the XML Sitemap or feed generator and does not duplicate provider-owned distribution logic.


## Active site context (0.10.0)

Hub 0.10.0 starts multisite support by consuming the site context that Geeklog has already selected. `HUB_siteContext()` exposes the active site URL, admin URL, host, scheme, site name and current Geeklog language as a read-only context object.

Hub deliberately does **not** select a site from the incoming host itself and does not persist a second Hub-owned site identifier. This follows the multisite Memorandum: plugins consume the active Geeklog configuration rather than implement parallel host routing.

Hub read services can include this site context so callers can distinguish which active site produced relationship, editorial and integrity data. `HUB_siteUrlContext()` can also classify a resolved URL as current-site, relative/current-site, or cross-site without modifying the relationship graph.


### Cross-site relationship context

Hub 0.10.0 enriches resolved relationship targets with site context derived from the active Geeklog site URL. Each relation can be classified as:

- `current-site` — relative URL or absolute URL on the configured active host;
- `cross-site` — resolved absolute URL on another host;
- `unknown` — unresolved or otherwise non-classifiable target.

Cross-site is context, not an integrity failure by itself. Hub does not rewrite the relation identity, move data between site databases, or infer a language from the target host.


### Object language context

Hub 0.10.0 keeps site language and object language separate.

For one provider-owned object, `HUB_objectLanguageContext()` accepts an object language only when the owning provider explicitly returns a non-empty `language` value through Item Info. When the provider does not expose that metadata, Hub reports the object language as unknown while still exposing the active Geeklog site language as context.

Hub does not infer an object's language from its domain, URL, slug, stable ID, or the active site's configured language. No object-language value is persisted by Hub.


### Equivalent-content relations

Hub 0.10.0 adds the structural relation role `equivalent` for administrator-approved equivalent content. Hub never infers this relationship automatically.

For an approved equivalent relation, integrity diagnostics report two independent dimensions:

- language evidence: `cross-language`, `same-language-review`, or `language-unverified`;
- site evidence: `cross-site`, `current-site`, or `unknown`.

The language status uses only provider-owned object language metadata when available. The site status uses resolved public URLs against the active Geeklog site context.

These diagnostics do not generate `hreflang`, choose a canonical translation, or manage translation workflows. Those responsibilities remain with the owning SEO/content layer.
